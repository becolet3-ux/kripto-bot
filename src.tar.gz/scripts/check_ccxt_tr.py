import ccxt
print("binancetr" in ccxt.exchanges)
